Dit is een voorbeeld om met JQUERY en php automatisch via ajax de stock indicatie van een product op te halen.
